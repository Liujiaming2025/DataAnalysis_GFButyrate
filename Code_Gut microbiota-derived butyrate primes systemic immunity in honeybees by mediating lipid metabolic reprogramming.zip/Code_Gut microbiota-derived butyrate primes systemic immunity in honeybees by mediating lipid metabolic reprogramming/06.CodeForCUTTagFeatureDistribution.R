###Feature Distribution###
rm(list = ls())

library(ChIPseeker)
library(GenomicFeatures)
library(ggplot2)
library(dplyr)

setwd("/Cuttag/")

file_list <- c("Buty-1_percentage.csv", "Buty-2_percentage.csv", "Buty-3_percentage.csv",
               "GF-1_percentage.csv", "GF-2_percentage.csv", "GF-3_percentage.csv")

all_data <- lapply(file_list, function(file) {
  data <- read.csv(file)
  sample_name <- gsub("_percentage.csv", "", basename(file)) 
  data$Sample <- sample_name
  return(data)
})

merged_data <- do.call(rbind, all_data)
colnames(merged_data)[1] <- "Region"
colnames(merged_data)[2] <- "Percentage"
colnames(merged_data)[3] <- "Sample"

custom_colors <- c(
  "Promoter" = "#4E79A7",
  "5UTR" = "#F28E2B",
  "3UTR" = "#E15759",
  "Exon" = "#76B7B2",
  "Intron" = "#59A14F",
  "Intergenic" = "#EDC949"
)

p <- ggplot(merged_data, aes(y = Sample, x = Percentage, fill = Region)) +
  geom_bar(
    stat = "identity", 
    position = "stack", 
    width = 0.6,       
    color = "black",  
    size = 0.2
  ) +
  scale_fill_manual(values = custom_colors) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Feature Distribution",
    x = "Percentage (%)",
    y = "Sample",
    fill = "Region"
  ) +
  theme_bw()+
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 12),
    axis.text.x = element_text(size = 12),
    axis.title = element_text(size = 14),
    panel.grid.major = element_line(color = "grey90", size = 0.2),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white", color = NA),
    legend.position = "right",
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12)
  )

ggsave("FeatureDistribution.pdf", p, width = 5.2, height = 3.3, units = "in")
