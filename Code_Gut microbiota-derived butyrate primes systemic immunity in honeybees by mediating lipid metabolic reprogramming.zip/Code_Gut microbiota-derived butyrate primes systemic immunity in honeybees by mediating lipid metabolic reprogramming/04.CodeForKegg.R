###Code for Kegg###
rm(list = ls())
setwd("/Kegg/")

library(enrichplot)
library(clusterProfiler)
library(ggplot2)
library(igraph)
library(dplyr)

info = read.csv("/Kegg/gene.csv", header = T)

KEGG_database <- 'ame'

geneid = info$geneid
head(geneid)

KEGG<-enrichKEGG(gene = geneid,
                 organism = KEGG_database,
                 pvalueCutoff = 0.05,
                 qvalueCutoff = 0.05)
write.csv(KEGG,file = "./result_KEGG.csv")

#--------------------------------------------------------------------------------------------------

data <- read.csv("result_KEGG.csv", row.names = 1)
data$Description <- gsub(" - Apis mellifera \\(honey bee\\)","",data$Description)
data <- subset(data, ID != "ame00513" & ID != "ame00510" & ID != "ame04141")
group <- read.csv("keggformap.csv")

nodes <- data[,c("ID","Description","p.adjust","Count")]
nodes <- left_join(nodes, group, by = "ID")
d <- apply(data, 1, function(x){unlist(strsplit(x[8],"/"))})
paths <- data$ID
df <- data.frame()
for (i in 1:length(d)) {
  for (j in i:length(d)) {
    if (i != j) {
      fromPathid <- paths[i]
      toPathid <- paths[j]
      intersectGene <- intersect(d[[fromPathid]], d[[toPathid]])
      fromPath <- nodes[which(nodes$ID == fromPathid),2]
      toPath <- nodes[which(nodes$ID == toPathid),2]
      fromPath.group <- nodes[which(nodes$ID == fromPathid),5]
      toPath.group <- nodes[which(nodes$ID == toPathid),5]
      df <- rbind(df, data.frame(from = fromPath, 
                                 to = toPath, 
                                 weight = if_else(fromPath.group == toPath.group, 20, 1),
                                 IntersectCounts = length(intersectGene))
                  )
    }
  }
}
edges <- df[which(df$IntersectCounts != 0),]

net_p <- graph_from_data_frame(d = edges,
                           vertices = nodes[,-1],
                           directed = FALSE)

vcolor <- RColorBrewer::brewer.pal(11, "Spectral")
vcolor
vcolor <- c("#9d0145","#F46D43","#fdffc8","#E6F598","#ABDDA4","#66C2A5","#3288BD","#5E4FA2","#a2a2a2")

pdf("KeggMap.pdf", width = 8, height = 5)
set.seed(20)
plot(net_p,
     vertex.size = -log10(nodes$p.adjust) * 6,
     vertex.color = vcolor[factor(nodes$Path_B_level)],
     vertex.label.color = "black",
     vertex.label.cex = 0.4,
     edge.color = "gray80",
     edge.width = edges$IntersectCounts / 2,
     layout = layout_with_fr
     )
nodes$p.adjust
p.adjust_vals <- sort(-log10(nodes$p.adjust))
-log10(nodes$p.adjust)
selected_vals <- c(min(p.adjust_vals), median(p.adjust_vals), max(p.adjust_vals))

legend("topright", 
       legend = round(selected_vals, 2),
       title = "-log10(p.adjust)", 
       pch = 21,
       pt.cex = selected_vals / max(selected_vals) * 6,
       bty = "n", 
       cex = 0.7)

dev.off()
