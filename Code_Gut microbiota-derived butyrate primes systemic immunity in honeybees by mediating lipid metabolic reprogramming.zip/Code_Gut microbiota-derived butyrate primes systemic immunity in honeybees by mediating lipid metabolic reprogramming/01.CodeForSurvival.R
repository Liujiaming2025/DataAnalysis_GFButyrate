###Survival###

rm(list = ls())
setwd("/Survival/")

data <- read.csv("Survival.csv", header = TRUE)

data$SurvivalRate <- data$Survival / 30
summary_data <- aggregate(SurvivalRate ~ Days + Treatment, data, mean)
summary_data$SD <- aggregate(SurvivalRate ~ Days + Treatment, data, sd)$SurvivalRate

library(ggplot2)

p<-ggplot(summary_data, aes(x = Days, y = SurvivalRate * 100, color = Treatment, group = Treatment)) +
  stat_summary(aes(alpha = Days), 
               geom = "line", fun = "mean", size = 0.8) +
  geom_errorbar(aes(ymin = (SurvivalRate - SD) * 100, ymax = (SurvivalRate + SD) * 100, color = Treatment, alpha = Days), 
                width = 0.15, size = 0.8) +
  geom_point(aes(fill = Treatment, alpha = Days), shape = 22, size = 4.3, stroke = 0) +
  
  scale_color_manual(values = c("GF" = "#7ea4d6", "CL" = "#f2d994", "butyrate" = "#f09890", "acetate" = "#9f9f9f")) +
  scale_fill_manual(values = c("GF" = "#7ea4d6", "CL" = "#f2d994", "butyrate" = "#f09890", "acetate" = "#9f9f9f")) +
  scale_alpha(range = c(1, 1)) +
  scale_y_continuous(breaks = seq(0, 100, by = 20)) +
  labs(title = "", x= "Days after infection", y="Survival (%)", fill="") +
  guides(color = "none", alpha = "none", fill = guide_legend(override.aes = list(shape = 22, size = 5))) +
  
  theme_bw() +
  theme(
    legend.position = "bottom",
    legend.background=element_blank(),
    legend.key = element_blank(),
    legend.margin=margin(0,0,0,0,"mm"),
    legend.text=element_text(size=10),
    legend.title = element_text(size=12),
    axis.text.x = element_text(size=12, colour = "black"),
    axis.text.y=element_text(size=12, colour = "black"),
    axis.line = element_line(linewidth = 0.5, color = "black"),
    axis.title = element_text(size=14, colour = "black"),
    axis.ticks = element_line(linewidth = 0.5, color = "black"),
    plot.title=element_text(size=14, hjust=0.5),
    panel.border=element_blank(),
    panel.grid = element_blank(),
    panel.background = element_blank()
  )
p
ggsave("Survival.pdf",p, width = 4, height = 3.5)

