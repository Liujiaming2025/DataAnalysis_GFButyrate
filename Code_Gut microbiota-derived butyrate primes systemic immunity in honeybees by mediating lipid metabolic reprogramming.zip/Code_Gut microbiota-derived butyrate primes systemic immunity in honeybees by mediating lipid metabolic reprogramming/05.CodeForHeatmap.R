###heatmap###
rm(list = ls())
setwd("/HeatmapNew/")

library(pheatmap)
library(ggplot2)

df_gene<-read.csv("Heatmap.csv",header = T,row.names = 1)
df_gene_log<-log(df_gene + 1)
df_col<-read.csv("annotation_col.csv",header = T,row.names = 1)

anno_color=list(Group_1=c(buty="#5f9a71",GF="#87a9cf"))

p=pheatmap(df_gene_log,
         annotation_col=df_col,
         annotation_colors = anno_color,
         cluster_rows=F,
         cluster_cols=F,
         show_colnames = F,
         scale = "row",
         color = colorRampPalette(c("#F5D389","white","#824CA2"))(800),
         fontsize = 10,
         fontsize_row = 6,
         fontsize_col = 6,
         cellwidth = 10,
         cellheight = 6.18,
         border_color = "black")
p
ggsave("Heatmap.pdf",p, width = 10, height = 6, units = "in")
