###qPCR###
library(ggplot2)
library(gcookbook)
library(plyr)
library(reshape2)
library(ggthemes)
library(scales)
library(gridExtra)
library(RColorBrewer)
library(tidyverse)
library(ggsci)
library(patchwork)
library(ggpubr)
library(gcplyr)
library(ggbreak)

rm(list = ls())

setwd("/Users/work")

data <- read.csv("qPCRdata.csv")
colnames(data)[1] <- "num"
data$group <- factor(data$group, levels = c("GF", "HK","CV"))

ebtop<-function(x){
  return(mean(x)+sd(x)/sqrt(length(x)))
} 
ebbottom<-function(x){
  return(mean(x)-sd(x)/sqrt(length(x)))
}

P1<-ggplot(data, aes(x=group, y=num,fill=group))+
  stat_summary(geom = "errorbar",
               fun.min = ebbottom,
               fun.max = ebtop,
               position = position_dodge(),
               width= 0.3,
               size = 0.5,
               color = "black")+
  stat_summary(mapping=aes(color = group),
               geom = "bar",fun = "mean",
               position = position_dodge(0.9),
               width= 0.6,
               size = 0.5
  )+

  facet_wrap(~time, scales = 'free_x',nrow=1) +
  scale_colour_manual(values = c('#88AAD0','#E0D483','#CC746F')) +
  scale_fill_manual(values = c('#88AAD0','#E0D483','#CC746F')) +
  scale_y_continuous(limits = c(),expand = c(0,0))+
  labs(title = "", x= "", y="Relative expression", sha = "", fil="") +
  theme_bw()+
  theme(
    legend.position = "none",
    legend.background=element_blank(),
    legend.key = element_blank(),
    legend.margin=margin(0,0,0,0,"mm"),
    legend.text=element_text(size=10), 
    legend.title = element_text(size=12),
    axis.text.x = element_text(size=12, colour = "black"),
    axis.text.y=element_text(size=12, colour = "black"),
    axis.line = element_line(linewidth = 0.5, color = "black"), 
    axis.title = element_text(size=14, colour = "black"), 
    axis.ticks = element_line(linewidth = 0.5, color = "black"), 
    plot.title=element_text(size=14, hjust=0.5), 
    panel.border=element_blank(), 
    panel.grid = element_blank(), 
    panel.background = element_blank(), 
    strip.text.x = element_text(size = 12, colour = "black"),
    strip.background = element_rect(linewidth = 0.47, fill="gray91", color='transparent') 
  )

P1
ggsave("AMP.pdf",P1, width = 4, height = 3.5) 