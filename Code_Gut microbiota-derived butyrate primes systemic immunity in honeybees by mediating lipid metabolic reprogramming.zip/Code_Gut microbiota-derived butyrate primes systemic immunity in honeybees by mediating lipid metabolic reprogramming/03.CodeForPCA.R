###PCA###
rm(list = ls())
setwd("/PCA/")

library(ggpubr)
library(ggthemes)
library(export)
library(factoextra)
library(ggplot2)
library(ggforce)
library(ggalt)
library(FactoMineR)
library(ggrepel)
library(plyr)

df <- read.csv("GF-Butyrate_fatbody.csv", header=TRUE,row.names = 1) 
df_log <- log(df + 1)  
df <- t(df_log)
df <- as.data.frame(df)

#---PCA---
pcdat <- PCA(df, ncp = 2, scale.unit = TRUE, graph = FALSE)
summary(pcdat)
fviz_eig(pcdat,addlabels = T) 
plot(pcdat) 

pca_sample <- data.frame(pcdat$ind$coord[ ,1:2]) 
head(pca_sample)
pca_eig1 <- round(pcdat$eig[1,2], 2) 
pca_eig2 <- round(pcdat$eig[2,2],2 )

group <- read.delim('group.txt', row.names = 1, sep = '\t', check.names = FALSE)
group <- group[rownames(pca_sample), ]
pca_sample <- cbind(pca_sample, group)

pca_sample$samples <- rownames(pca_sample)
head(pca_sample)

p <-ggplot(data = pca_sample, aes(x = Dim.1, y = Dim.2))+
  geom_point(aes(color = group), size = 3)+
  scale_color_manual(values = c('#5f9a71', '#87a9cf'))+
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(color = 'black', fill = 'transparent'), 
        legend.key = element_rect(fill = 'transparent'))+
  labs(x =  paste('PCA1:', pca_eig1, '%'), y = paste('PCA2:', pca_eig2, '%'), color = '')

cluster_border <- ddply(pca_sample, 'group', function(df) df[chull(df[[1]], df[[2]]), ])

p + geom_polygon(data = cluster_border, aes(color = group), fill = NA, show.legend = FALSE)
p + geom_polygon(data = cluster_border, aes(fill = group), alpha = 0.2, show.legend = FALSE) +
  scale_fill_manual(values = c('#5f9a71', '#87a9cf'))
p_final <-
  p + geom_polygon(data = cluster_border, aes(fill = group), alpha = 0.2, show.legend = FALSE) +
  scale_fill_manual(values = c('#5f9a71', '#87a9cf'))

ggsave("GF-Butyrate_fatbody_PCA.pdf", plot = p_final, width = 4, height = 2.3, units = "in")

